function login() {
    var ws = new WebSocket("ws://uralez.de:8080");
    ws.onopen = function (event) {

        var msg = {
            type: "login",
            username: (<HTMLInputElement>document.getElementById('username')).value,
            password: (<HTMLInputElement>document.getElementById('password')).value
        };
        ws.send(JSON.stringify(msg));

    };
    ws.onerror = function (err) {
    }
    ws.onmessage = function (event) {
        console.log(event.data);
        var msg = JSON.parse(event.data);
        if (msg.login) {
            var curDate = new Date();
            curDate.setTime(curDate.getTime() + (7200000));
            var expires = "; expires=" + curDate.toUTCString();
            document.cookie = "username=" + msg.username + expires + "; path=/";
            window.location.href = "http://uralez.de:8081";
        } else {
            window.alert("Wrong Password and/or Username!");
            (<HTMLInputElement>document.getElementById('username')).value = "";
            (<HTMLInputElement>document.getElementById('password')).value = "";
        }
    };
    ws.onclose = function () {
    }
}


function register() {
    var ws = new WebSocket("ws://uralez.de:8080");
    ws.onopen = function (event) {

        var msg = {
            type: "register",
            username: (<HTMLInputElement>document.getElementById('username')).value,
            password: (<HTMLInputElement>document.getElementById('password')).value
        };

        ws.send(JSON.stringify(msg));

    };
    ws.onerror = function (err) {
    }
    ws.onmessage = function (event) {
        console.log(event.data);
        var msg = JSON.parse(event.data);
        if (msg.registered == true) {
            window.alert("User registered!");
        } else {
            window.alert("User failed to register!");
        }
        ;
    }

    ws.onclose = function () {
    }
}

function createCookie(username) {
    document.cookie = "username=" + username;
}