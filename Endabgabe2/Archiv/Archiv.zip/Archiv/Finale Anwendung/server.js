var WebSocketServer = require('ws').Server;
var wss = new WebSocketServer({ port: 8080 });
var mysql = require('mysql');
var db_config = {
    host: 'localhost',
    user: 'chat',
    password: 'zCOYrg8gUkX4OAKN',
    database: 'chat'
};
var con;
function handleDisconnect() {
    con = mysql.createConnection(db_config);
    con.connect(function (err) {
        if (err) {
            console.log('error when connecting to db:', err);
            setTimeout(handleDisconnect, 2000);
        }
    });
    con.on('error', function (err) {
        console.log('db error', err);
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            handleDisconnect();
        }
        else {
            throw err;
        }
    });
}
handleDisconnect();
function checkLogin(ws, givenUsername, givenPassword) {
    handleDisconnect();
    console.log(givenUsername);
    console.log(givenPassword);
    var result = false;
    var sql = "SELECT * FROM users WHERE username='" + givenUsername + "' and password='" + givenPassword + "'";
    con.query(sql, function (err, result) {
        if (err)
            throw err;
        console.log(result);
        if (result[0]) {
            console.log("Correct");
            var msg = {
                login: true,
                username: result[0].username
            };
            ws.send(JSON.stringify(msg));
        }
        else {
            console.log("Incorrect");
            var msg2 = {
                login: false
            };
            ws.send(JSON.stringify(msg2));
        }
    });
}
function registerUser(ws, givenUsername, givenPassword) {
    handleDisconnect();
    console.log(givenUsername);
    console.log(givenPassword);
    var msgfail = {
        registered: false
    };
    var msgsuccess = {
        registered: true
    };
    if (givenUsername == "") {
        ws.send(JSON.stringify(msgfail));
    }
    else {
        var sqlIsRegistered = "SELECT * FROM users WHERE username='" + givenUsername + "'";
        con.query(sqlIsRegistered, function (err, result) {
            if (err)
                throw err;
            console.log(result);
            if (result[0]) {
                ws.send(JSON.stringify(msgfail));
            }
            else {
                var sql = "INSERT INTO users (username, password) VALUES ('" + givenUsername + "', '" + givenPassword + "')";
                con.query(sql, function (err, result) {
                    if (err)
                        throw err;
                    console.log(result);
                    var msg = {
                        registered: true
                    };
                    ws.send(JSON.stringify(msgsuccess));
                });
            }
        });
    }
}
wss.on('connection', function (ws) {
    ws.onmessage = function (event) {
        var msg = JSON.parse(event.data);
        console.log(msg.type);
        if (msg.type == "login") {
            checkLogin(ws, msg.username, msg.password);
        }
        else if (msg.type == "register") {
            registerUser(ws, msg.username, msg.password);
        }
    };
    ws.on('end', function () {
        console.log('Connection ended...');
    });
});
