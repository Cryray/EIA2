var mysql = require('mysql');
var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);

var db_config = {
    host: 'localhost',
    user: 'chat',
    password: 'zCOYrg8gUkX4OAKN',
    database: 'chat'
};

var con;

function handleDisconnect() {
    con = mysql.createConnection(db_config);

    con.connect(function (err) {
        if (err) {
            console.log('error when connecting to db:', err);
            setTimeout(handleDisconnect, 2000);
        }
    });

    con.on('error', function (err) {
        console.log('db error', err);
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            handleDisconnect();
        } else {
            throw err;
        }
    });
}

function sendMessage(username, message) {
    var timestamp = (new Date()).getTime();
    var sql = "INSERT INTO chatlog (timestamp, username, message) VALUES ?";
    var msg = [[timestamp, username, message]];
    con.query(sql, [msg], function (err, result) {
        if (err) throw err;
        console.log("Message sent");
    });
}

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/room1.html');
});

io.on('connection', function (socket) {
    console.log('A user connected to the server!');
    io.emit('servermsg', 'SERVER: A user connected to the Server!');

    socket.emit('A user connected to room 1!');

    socket.on('disconnect', function () {
        console.log('A user disconnected from the server.');
    });
    handleDisconnect();
    var sql = "SELECT * FROM (SELECT * FROM `chatlog` ORDER BY `timestamp` DESC LIMIT 20)Var1 ORDER BY `timestamp` ASC";
    con.query(sql)
    con.query(sql, function (err, result) {
        if (err) throw err;
        var i;
        for (i = 0; i < result.length; i++) {
            io.to(socket.id).emit('room', result[i].username, result[i].message);
        }
        return result;
    });


    socket.on('room', function (usr, msg) {
        if (msg.length != 0) {
            io.emit('room', usr, msg);
            console.log('room2: ' + usr + ' ' + msg);
            sendMessage(usr, msg);
        }
    });
});

http.listen(8082, function () {
    console.log('listening on *:8082');
});